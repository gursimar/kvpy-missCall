
//		InfraRed Remote Control Receiver for Sony's IR remote controls
//		(c) 09.Aug.2008 by Vassilis Serasidis
//
//		Target: ATtiny13 at 4.8MHz internal RC oscillator
//		Disable the "Divide by 8" option under fuses tab.
//		IR module: TSOP1730 (30kHz). Works with TSOP1736 too (36kHz).
//
//		Usage:
//		To setup the "POWER" key for powering ON or OFF your PC press SW button on the remote control receiver and keep it pressed.
//		Press any key on your remote control once and leave it. Leave the SW button too. Your "POWER" key has been programmed.
//		
//		The serial transmittion from ATtiny13 to PC media center has been set to 2400 bps.
//
//		http://www.serasidis.gr
//		avrsite@yahoo.gr
//		info@serasidis.gr
//		This source code is distributed under GPL V2 license.
//
//		V1.01 --- 18.Aug.2008 
//				- Fixed a problem with the serial communication.
//				- Decreased the delay time for "Power On/Off" function from 2 seconds to 1 second.
//		V1.00 --- 09.Aug.2008 :: Initial version

#include <avr/io.h>
#include <util/delay.h>
#include <avr/eeprom.h>


#define TXD		PB1
#define INPUT	PB2
#define SW		PB3
#define POWER	PB4
#define COMMANDBIT	7 //0b10000000

unsigned char	temp;
unsigned char	bitCounter;
unsigned char	address;
unsigned char	command;
unsigned char   counter;
unsigned char	eepromCommand = 0x00;
unsigned char   eepromAddress = 0x04;



int main (void)
{
	PORTB = 0B00001000;
	DDRB = 0B00010010;

	for(;;)
	{
	
		while(!(~PINB & (1<<INPUT)))
		{
			PORTB &= ~(1 << POWER);
		}
		address = 0;
		command = 0;


		_delay_us(3100); // delay to finish the start bit
		
		for(bitCounter = 7;bitCounter >0;bitCounter--) //7-bit command length (button number).
		{	
			_delay_us(800);// delay the 3/4 of a bit length.


			if(!(~PINB & (1<<INPUT)))
			{
				command &= ~(1 << COMMANDBIT);
				command >>= 1;
			}
			else
			{
				command |= (1 << COMMANDBIT);
				command >>= 1;
				_delay_us(590);
			}
		_delay_us(350);
		}

		for(bitCounter = 5;bitCounter >0;bitCounter--) //5-bit address length (device address).
		{	
			_delay_us(800);// delay the 3/4 of a bit length.

			if(!(~PINB & (1<<INPUT)))
			{
				address &= ~(1 << COMMANDBIT);
				address >>= 1;
			
			}
			else
			{
				address |= (1 << COMMANDBIT);
				address >>= 1;
				_delay_us(590);
			}

			_delay_us(350);
		}

		sendTxD(command); //Send six bytes to Girder IR software. 
		sendTxD(address);
		sendTxD(command);
		sendTxD(address);
		sendTxD(command);
		sendTxD(address);

		checkForValidKey();

		if (~PINB & (1<<SW))
		{
			eeprom_write_byte(0x01,command);
			eeprom_write_byte(0x02,address);
			while(~PINB & (1<<SW))
				_delay_ms(500);
		}
		
		


// wait until a small time of period with Logic "1" at the INPUT pin will pass.
// This is used to ensure that the next IR signal will begin from the start bit and
// not from a random LOW signal at the middle of the IR signal (the start bit beggins with LOW).
		for(counter = 0; counter < 250;) 
		{
			if (!(~PINB & (1<<INPUT)))
				counter++;
			else
				counter = 0;

			_delay_us(100);
		}
		
	}

}

//===================================================================
//
//===================================================================
void checkForValidKey (void)
{
	eepromCommand = eeprom_read_byte(0x01);
	eepromAddress = eeprom_read_byte(0x02);

	if((eepromCommand == command) && (eepromAddress == address))
	{
		PORTB |= (1 << POWER);
		_delay_ms(1);
		command = 0;
		address = 0;
	}
}


//===================================================================
// Software based Serial Transmitter
// (2400 bps at 4.8MHz internal RC oscillator).
//===================================================================
void sendTxD (unsigned char txd)
{
	PORTB |= (1 << TXD);
		_delay_us(405);
	for(bitCounter=8; bitCounter>0; bitCounter--)
	{
		if (bit_is_clear(txd, 0))
			PORTB |= (1 << TXD);
		else
			PORTB &= ~(1 << TXD);

		_delay_us(405);
		txd >>= 1;
	}
	PORTB &= ~(1 << TXD);
	_delay_us(405);
}
